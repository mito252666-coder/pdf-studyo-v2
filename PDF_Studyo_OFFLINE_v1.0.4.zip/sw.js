// PDF Stüdyo — çevrimdışı önbellek. Vendor dosyaları tamamlandığında hepsi önbelleğe alınır.
const CACHE_NAME = 'pdf-studyo-offline-v1.0.4';
const CORE = [
  './', './index.html', './manifest.webmanifest', './icon-192.svg', './icon-512.svg',
  './vendor/tailwind.browser.js', './vendor/lucide.min.js',
  './vendor/pdf.min.js', './vendor/pdf.worker.min.js', './vendor/pdf-lib.min.js',
  './vendor/qpdf-wasm/index.js', './vendor/qpdf-wasm/qpdf.wasm'
];
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    // Eksik vendor dosyaları servis çalışanının kurulumunu tamamen bozmasın.
    await Promise.all(CORE.map(async path => {
      try { const response = await fetch(path); if (response.ok) await cache.put(path, response); }
      catch (_) { /* Bu dosya eklenene kadar atlanır. */ }
    }));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('pdf-studyo-') && k !== CACHE_NAME).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(req).then(hit => hit || fetch(req).then(res => {
    if (res.ok) { const copy = res.clone(); caches.open(CACHE_NAME).then(c => c.put(req, copy)); }
    return res;
  }).catch(() => caches.match('./index.html'))));
});
